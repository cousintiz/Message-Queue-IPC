#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>
#include <pthread.h>
#include <signal.h>
#include <semaphore.h>
#include <malloc.h>
#include <ros/ros.h>
#include <sensor_msgs/point_cloud_conversion.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/PointCloud2.h>

#define TSCSECF     1e9

typedef struct{
    double *x, *y, *z;
    int npoints;
}t_point_cloud;

/*mutex para threads*/
sem_t sem1, sem2;
pthread_mutex_t m1 = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t c1 = PTHREAD_COND_INITIALIZER;
pthread_mutex_t m2 = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t c2 = PTHREAD_COND_INITIALIZER;
int done1=0;
int done2=0;

ros::Publisher pub;

/*global var for cloud pointers stages of processing*/
t_point_cloud *cloud_raw, *cloud_drivable, *cloud_clean,*buffer1,*buffer2;

struct timespec loop;
void read_data(const sensor::PointCloud2ConstPtr &msg);
void clean_data();
void drivable_data();

double sectimeget(struct timespec *ts);

void* f1(void *args){

    ros::NodeHandle node;
    ros::Subscriber sub = node.subscribe("/velodyne_points", 10, read_data);
            
    clock_nanosleep(CLOCK_MONOTONIC,TIMER_ABSTIME,&loop,&remain);
    loop.tv_nsec=loop.tv_nsec + 100000000;
    if(loop.tv_nsec>=1000000000){
        loop.tv_nsec=loop.tv_nsec-1000000000;
        loop.tv_sec=loop.tv_sec+1;
    }
    clock_gettime(CLOCK_MONOTONIC,&time1);
    sub.tv_sec=time1.tv_sec-time2.tv_sec;
    sub.tv_nsec=time1.tv_nsec-time2.tv_nsec;
    
    /*publicar os pontos*/
    pub = node.advertise<sensor_msgs::PointCloud>("/velodyne_points2", 10); 
    ros::spin();
    
    pthread_mutex_lock(&m1);
    done1 = 1;
    pthread_cond_signal(&c1);   
    pthread_mutex_unlock(&m1);
    time2.tv_sec=time1.tv_sec;
    time2.tv_nsec=time1.tv_nsec;

    pthread_exit(NULL);
}

void* f2(void *args){
    // clean data
    while(1){
        pthread_mutex_lock(&m1);
        while (done1 == 0){
            pthread_cond_wait(&c1, &m1);
        }
        done1=0;
        pthread_mutex_unlock(&m1);    
        
        clean_data();
        fflush(stdout);


        pthread_mutex_lock(&m2);
        done2 = 1;
        pthread_cond_signal(&c2);   
        pthread_mutex_unlock(&m2);
    }

    pthread_exit(NULL);
}

void* f3(void *args){
    //drivable 
    
    sensor_msgs::PointCloud point_cloud;
    point_cloud.header.frame_id = "velodyne";

    while(1){
        pthread_mutex_lock(&m2);
        while (done2 == 0){
            pthread_cond_wait(&c2, &m2);
        }
        done2=0;
        pthread_mutex_unlock(&m2);
        
        drivable_data();
        fflush(stdout);
        pub.publish(point_cloud);
    }

    pthread_exit(NULL);
}

int main(int argc, char *argv[]){

    /*threads var*/
    pthread_t t_f1, t_f2, t_f3; 
    struct timespec wait,remain;
    wait.tv_sec=0;
    wait.tv_nsec=5000;
    cloud_raw = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    cloud_clean = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    cloud_drivable = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    buffer1 = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    buffer2 = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    

    clock_gettime(CLOCK_MONOTONIC,&loop);
    loop.tv_sec=loop.tv_sec+1;
    /*mutex init*/
    if(sem_init(&sem1, 0, 0) == -1){
		printf("Error ");
		exit(EXIT_FAILURE);
	}
    if(sem_init(&sem2, 0, 0) == -1){
		printf("Error ");
		exit(EXIT_FAILURE);
	}


    ros::init(argc, argv, "str23");

    /*create threads*/
    if(pthread_create(&t_f1,NULL,f1,NULL)){
        puts("error creating threads");
        exit(-1);
    }
    printf("AFTER THREAD1 INIT\n");
    fflush(stdout);

    clock_nanosleep(CLOCK_MONOTONIC,0,&wait,&remain);
    if(pthread_create(&t_f2,NULL,f2,NULL)){
        puts("error creating threads");
        exit(-1);
    }
    printf("AFTER THREAD2 INIT\n");
    fflush(stdout);
    clock_nanosleep(CLOCK_MONOTONIC,0,&wait,&remain);
    if(pthread_create(&t_f3,NULL,f3,NULL)){
        puts("error creating threads");
        exit(-1);
    }
    printf("AFTER THREAD3 INIT\n");
    fflush(stdout);
    /*wait for threads to finish*/
    pthread_join(t_f1, NULL);
    pthread_join(t_f2, NULL);
    pthread_join(t_f3, NULL);

    /*destroy mutex*/
     if(sem_destroy(&sem1) == -1){
		printf("Error ");
		exit(EXIT_FAILURE);
	}
     if(sem_destroy(&sem2) == -1){
		printf("Error ");
		exit(EXIT_FAILURE);
	}


    return 0;
}

double sectimeget(struct timespec *ts)
{
    double tsc;
    tsc = ts->tv_nsec;
    tsc /= TSCSECF;
    tsc += ts->tv_sec;
    return tsc;
}

void read_data(const sensor::PointCloud2ConstPtr &msg){
    unsigned int lines = 0;
    char buffer[100];
    double aux = 0.0;
    double sum[3] = {0.0,0.0,0.0}, prod[3] = {0.0,0.0,0.0}; 
    double mean[3] = {0.0,0.0,0.0}, dev[3] = {0.0,0.0,0.0}; 
    double min[3] = {0.0,0.0,0.0}, max[3] = {0.0,0.0,0.0}; /*0,1,2 = x, y, z*/

    sensor::PointCloud cloud;
    sensor::convertPointCloud2ToPointCloud(*msg, cloud);
    size_t lines = cloud.points.size(); 

    cloud_raw->npoints = lines;
    cloud_raw->x = (double *) realloc(cloud_raw->x,lines* sizeof(double));
    cloud_raw->y = (double *) realloc(cloud_raw->y,lines* sizeof(double));
    cloud_raw->z = (double *) realloc(cloud_raw->z,lines* sizeof(double));
    buffer1->npoints = lines;
    buffer1->x = (double *) realloc(buffer1->x,lines* sizeof(double));
    buffer1->y = (double *) realloc(buffer1->y,lines* sizeof(double));
    buffer1->z = (double *) realloc(buffer1->z,lines* sizeof(double));
    fseek(file, 0, SEEK_SET); /*por pointer no começo*/
    
    for(int i = 0; i < cloud_raw->npoints; i++){
        fscanf(file, "%lf %lf %lf\n", &cloud_raw->x[i], &cloud_raw->y[i], &cloud_raw->z[i]);/*ler dados*/
        sum[0] += cloud_raw->x[i]; 
        sum[1] += cloud_raw->y[i];
        sum[2] += cloud_raw->z[i];
        prod[0] += cloud_raw->x[i] * cloud_raw->x[i];
        prod[1] += cloud_raw->y[i] * cloud_raw->y[i];
        prod[2] += cloud_raw->z[i] * cloud_raw->z[i];

    }
    for(int i = 0; i < cloud_raw->npoints; i++){
        buffer1->x[i]=cloud_raw->x[i];
        buffer1->y[i]=cloud_raw->y[i];
        buffer1->z[i]=cloud_raw->z[i];
    }

    sem_post(&sem1);

    for(int i = 0; i < 3; i++){
        mean[i] = sum[i] / cloud_raw->npoints;/*mean = sum / n*/
        aux = (prod[i]/cloud_raw->npoints - (mean[i]*mean[i]));  /* std = sqrt(prod/n - mean^2)*/
        dev[i] = sqrt( aux);
    }
    
    for(int i = 0; i < cloud_raw->npoints; i++){
        /*minimos*/
        if(min[0] > cloud_raw->x[i]){
            min[0] = cloud_raw->x[i];
        }
        if(min[1] > cloud_raw->y[i]){
            min[1] = cloud_raw->y[i];
        }
        if(min[2] > cloud_raw->z[i]){
            min[2] = cloud_raw->z[i];
        }

        /*maximos*/
        if(max[0] < cloud_raw->x[i]){
            max[0] = cloud_raw->x[i];
        }
        if(max[1] < cloud_raw->y[i]){
            max[1] = cloud_raw->y[i];
        }
        if(max[2] <cloud_raw->z[i]){
            max[2] = cloud_raw->z[i];
        }

    }
    
    printf("\nXmax = %lf, Ymax = %lf, Zmax = %lf\n\n", max[0], max[1], max[2]);
    fflush(stdout);
    printf("Xmin = %lf, Ymin = %lf, Zmin = %lf\n\n", min[0], min[1], min[2]);
    fflush(stdout);
    printf("Xmean = %lf, Ymean = %lf, Zmean = %lf\n\n", mean[0], mean[1], mean[2]);
    fflush(stdout);
    printf("Xstdev = %lf, Ystdev = %lf, Zstdev = %lf\n\n", dev[0], dev[1], dev[2]);
    fflush(stdout);

    if(fclose(file) == -1){
		printf("ERROR closing FILE\n");
		exit(1);
	}	
   
}

void clean_data(){
    sem_wait(&sem1);
    int clean_npoints=buffer1->npoints;
    int j=0;
    double x[buffer1->npoints];
    double y[buffer1->npoints];
    double z[buffer1->npoints];

    for(int i = 0; i < buffer1->npoints; i++){
        if (buffer1->x[i]<2||buffer1->x[i]>30){
            clean_npoints--;
            continue;
        }
        if ( buffer1->y[i]>10 || buffer1->y[i]<-10){
            clean_npoints--;
            continue;
        }
        x[j] = buffer1->x[i];
        y[j] = buffer1->y[i];
        z[j] = buffer1->z[i];
        j++;
    }
    
    buffer2->npoints = clean_npoints;
    buffer2->x = (double *) realloc(buffer2->x,clean_npoints* sizeof(double));
    buffer2->y = (double *) realloc(buffer2->y,clean_npoints* sizeof(double));
    buffer2->z = (double *) realloc(buffer2->z,clean_npoints* sizeof(double));
    malloc_trim(0);
    
    for(int i = 0; i < clean_npoints; i++){
        buffer2->x[i]=x[i];
        buffer2->y[i]=y[i];
        buffer2->z[i]=z[i];
    }
    sem_post(&sem2);
    cloud_clean->npoints = clean_npoints;
    cloud_clean->x = (double *) realloc(cloud_clean->x,clean_npoints* sizeof(double));
    cloud_clean->y = (double *) realloc(cloud_clean->y,clean_npoints* sizeof(double));
    cloud_clean->z = (double *) realloc(cloud_clean->z,clean_npoints* sizeof(double));
    malloc_trim(0);
    
    printf("NºPoints CLEAN %d\n",clean_npoints);fflush(stdout);

    for(int i = 0; i < clean_npoints; i++){
        cloud_clean->x[i]=x[i];
        cloud_clean->y[i]=y[i];
        cloud_clean->z[i]=z[i];
    }
}

void swap(double *a, double *b) {
  double t = *a;
  *a = *b;
  *b = t;
}

int partition(t_point_cloud *cloud, int low, int high) {
  
  // select the c element as pivot
  double pivot = cloud->x[high];
  
  // pointer for greater element
  int i = (low - 1);

  // traverse each element of the array
  // compare them with the pivot
  for (int j = low; j < high; j++) {
    if (cloud->x[j] <= pivot) {
        
      // if element smaller than pivot is found
      // swap it with the greater element pointed by i
      i++;
      
      // swap element at i with element at j
      swap(&cloud->x[i], &cloud->x[j]);
      swap(&cloud->y[i], &cloud->y[j]);
      swap(&cloud->z[i], &cloud->z[j]);
    }
  }

  // swap the pivot element with the greater element at i
  
  swap(&cloud->x[i+1], &cloud->x[high]);
  swap(&cloud->y[i+1], &cloud->y[high]);
  swap(&cloud->z[i+1], &cloud->z[high]);
  // return the partition point
  return (i + 1);
}

void quickSort(t_point_cloud *cloud, int low, int high) {
  if (low < high) {
    
    // find the pivot element such that
    // elements smaller than pivot are on left of pivot
    // elements greater than pivot are on right of pivot
    int pi = partition(cloud, low, high);
    
    // recursive call on the left of pivot
    quickSort(cloud, low, pi - 1);
    
    // recursive call on the right of pivot
    quickSort(cloud, pi + 1, high);
  }
}

void drivable_data(){
    sem_wait(&sem2);
    double x[buffer2->npoints];
    double y[buffer2->npoints];
    double z[buffer2->npoints];
    int section_npoints=0;
    double begin_section=2;
    double slope;
    int drivable_npoints=0;
    int total_iter=0;
    int exit=0;
    double reference_point[3];
    double max_slope=0.3;
    quickSort(buffer2,0,buffer2->npoints-1);

    //Primeiro ponto de referencia
    //for procura da condição de y
    for(int i=0;i<buffer2->npoints;i++){
        if(buffer2->y[i]<1 && buffer2->y[i]>-1){
            reference_point[0]=buffer2->x[i];
            reference_point[1]=buffer2->y[i];
            reference_point[2]=buffer2->z[i];
            break;
        }
    }
    
    while(begin_section<buffer2->x[buffer2->npoints-1]){
        for(int i = total_iter; i < buffer2->npoints; i++){
            if (buffer2->x[i]>begin_section && buffer2->x[i]<begin_section+0.2){
                section_npoints++;
                continue;
            }
            if(buffer2->x[i]>begin_section+0.2){
                break;
            }
        }

        begin_section+=0.2;

        //for na secção à procura de ponto de referencia
        //condição de paragem o slope com o ponto de refencia anterior ser <20%
        for(int i=total_iter;i<total_iter +section_npoints;i++){
            if(buffer2->y[i]<1 && buffer2->y[i]>-1){
                slope=(buffer2->z[i]-reference_point[2]);
                if(slope<max_slope && slope>0-max_slope){
                    reference_point[0]=buffer2->x[i];
                    reference_point[1]=buffer2->y[i];
                    reference_point[2]=buffer2->z[i];
                    break;
                }
            }
        }


        for(int i=total_iter;i<total_iter+section_npoints;i++){
            slope=buffer2->z[i]-reference_point[2];
            if(buffer2->y[i]<1 && buffer2->y[i]>-1){
                if(slope>max_slope || slope<0-max_slope){
                    exit=1;
                    break;
                }

            }
            if(slope>max_slope || slope< 0-max_slope){
                continue;
            }
            
            x[drivable_npoints]=buffer2->x[i];
            y[drivable_npoints]=buffer2->y[i];
            z[drivable_npoints]=buffer2->z[i];
            drivable_npoints++;
        }

        
        total_iter+=section_npoints;
        section_npoints=0;
        if(exit){
            break;
        }
        
    }
    
    printf("Nº Points Drivable %d\n\n",drivable_npoints);

    cloud_drivable->x = (double *) realloc(cloud_drivable->x, drivable_npoints* sizeof(double));
    cloud_drivable->y = (double *) realloc(cloud_drivable->y,drivable_npoints* sizeof(double));
    cloud_drivable->z = (double *) realloc(cloud_drivable->z,drivable_npoints* sizeof(double));
    cloud_drivable->npoints = drivable_npoints;    
    malloc_trim(0);
    for(int i = 0; i < cloud_drivable->npoints; i++){
        cloud_drivable->x[i] = x[i];
        cloud_drivable->y[i] = y[i];
        cloud_drivable->z[i] = z[i];
    }
}


