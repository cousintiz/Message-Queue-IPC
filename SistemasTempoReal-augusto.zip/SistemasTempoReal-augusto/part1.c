#define _GNU_SOURCE
#define TSCSECF     1e9
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include <malloc.h>

typedef struct{
    double *x, *y, *z;
    int npoints;
}t_point_cloud;

/*global var for cloud pointers stages of processing*/
t_point_cloud *cloud_raw, *cloud_data, *cloud_clean; 

t_point_cloud* read_data(char *filename);
t_point_cloud* clean_data(t_point_cloud* raw);
t_point_cloud* drivable_data(t_point_cloud* cloud);
double sectimeget(struct timespec *ts);
void bubbleSort(t_point_cloud* cloud, int n);

int main(int argc, char *argv[]){

    struct timespec startp;
    struct timespec endp;
    double start,end,read_time,clean_time,drivable_time;
    char* namefile = "point_cloud1.txt";

    clock_gettime(CLOCK_MONOTONIC, &startp);
    cloud_raw = read_data(namefile); /*read data from file*/
    clock_gettime(CLOCK_MONOTONIC, &endp);
    start = sectimeget(&startp);
    end = sectimeget(&endp);
    read_time = end - start;

    clock_gettime(CLOCK_MONOTONIC, &startp);
    cloud_clean = clean_data(cloud_raw); /*remover pontos desnecessarios*/
    clock_gettime(CLOCK_MONOTONIC, &endp);
    start = sectimeget(&startp);
    end = sectimeget(&endp);
    clean_time = end - start; 

    clock_gettime(CLOCK_MONOTONIC, &startp);
    cloud_data = drivable_data(cloud_clean);/*slope e objets*/
    clock_gettime(CLOCK_MONOTONIC, &endp);
    start = sectimeget(&startp);
    end = sectimeget(&endp);
    drivable_time = end - start;

    printf("READ - %.4f\nCLEAN - %.4f\n DRIVABLE - %.4f\n\nTOTAL - %.4f\n",read_time,clean_time,drivable_time,read_time+clean_time+drivable_time);

    /*libertar memoria*/
    free(cloud_data);

    return 0;
}

double sectimeget(struct timespec *ts)
{
    double tsc;
    tsc = ts->tv_nsec;
    tsc /= TSCSECF;
    tsc += ts->tv_sec;
    return tsc;
}

t_point_cloud* read_data(char *filename){
    unsigned int lines = 0;
    char buffer[100];
    double aux = 0.0;
    t_point_cloud *cloud;
    double sum[3] = {0.0,0.0,0.0}, prod[3] = {0.0,0.0,0.0}; 
    double mean[3] = {0.0,0.0,0.0}, dev[3] = {0.0,0.0,0.0}; 
    double min[3] = {0.0,0.0,0.0}, max[3] = {0.0,0.0,0.0}; /*0,1,2 = x, y, z*/

   
    FILE *file = fopen(filename,"r");/*abrir ficheiro para leitura*/
    if( file == NULL){
        printf("error opening file: %s", filename);
        exit(EXIT_FAILURE);
    }

    /*saber nr de linhas/size de dados a alocar*/
    while(fgets(buffer, sizeof(buffer), file)){
        lines++;
    }
    printf("num of points: %d \n", lines); 

    /*alocar espaço x,y,z*/
    cloud = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    cloud->npoints = lines;
    cloud->x = (double *) malloc(lines* sizeof(double));
    cloud->y = (double *) malloc(lines* sizeof(double));
    cloud->z = (double *) malloc(lines* sizeof(double));
     
    fseek(file, 0, SEEK_SET); /*por pointer no começo*/
    
    for(int i = 0; i < cloud->npoints; i++){
        fscanf(file, "%lf %lf %lf\n", &cloud->x[i], &cloud->y[i], &cloud->z[i]);/*ler dados*/
        sum[0] += cloud->x[i]; 
        sum[1] += cloud->y[i];
        sum[2] += cloud->z[i];
        prod[0] += cloud->x[i] * cloud->x[i];
        prod[1] += cloud->y[i] * cloud->y[i];
        prod[2] += cloud->z[i] * cloud->z[i];

    }
   
    for(int i = 0; i < 3; i++){
        mean[i] = sum[i] / cloud->npoints;/*mean = sum / n*/
        aux = (prod[i]/cloud->npoints - (mean[i]*mean[i]));  /* std = sqrt(prod/n - mean^2)*/
        dev[i] = sqrt( aux);
    }
    
    for(int i = 0; i < cloud->npoints; i++){
        /*minimos*/
        if(min[0] > cloud->x[i]){
            min[0] = cloud->x[i];
        }
        if(min[1] > cloud->y[i]){
            min[1] = cloud->y[i];
        }
        if(min[2] > cloud->z[i]){
            min[2] = cloud->z[i];
        }

        /*maximos*/
        if(max[0] < cloud->x[i]){
            max[0] = cloud->x[i];
        }
        if(max[1] < cloud->y[i]){
            max[1] = cloud->y[i];
        }
        if(max[2] <cloud->z[i]){
            max[2] = cloud->z[i];
        }

    }
    
    printf("\nXmax = %lf, Ymax = %lf, Zmax = %lf\n\n", max[0], max[1], max[2]);
    printf("Xmin = %lf, Ymin = %lf, Zmin = %lf\n\n", min[0], min[1], min[2]);
    printf("Xmean = %lf, Ymean = %lf, Zmean = %lf\n\n", mean[0], mean[1], mean[2]);
    printf("Xstdev = %lf, Ystdev = %lf, Zstdev = %lf\n\n", dev[0], dev[1], dev[2]);
   
    return cloud;
}

t_point_cloud* clean_data(t_point_cloud* raw){

    int clean_npoints=raw->npoints;
    int j=0;
    double x[raw->npoints];
    double y[raw->npoints];
    double z[raw->npoints];

    for(int i = 0; i < raw->npoints; i++){
        if (raw->x[i]<2||raw->x[i]>30){
            clean_npoints--;
            continue;
        }
        if ( raw->y[i]>10 || raw->y[i]<-10){
            clean_npoints--;
            continue;
        }
        x[j] = raw->x[i];
        y[j] = raw->y[i];
        z[j] = raw->z[i];
        j++;
    }

    //printf("PROBLEM START\n");
    raw->x = (double *) realloc(raw->x,clean_npoints* sizeof(double));
    raw->y  = (double *) realloc(raw->y,clean_npoints* sizeof(double));
    raw->z = (double *) realloc(raw->z,clean_npoints* sizeof(double));
    malloc_trim(0);
    // int *a;
    // a=(int*)malloc(sizeof(int));
    raw->npoints=clean_npoints;
    //printf("PROBLEM END\n");
    for(int i = 0; i < raw->npoints; i++){
        raw->x[i] = x[i];
        raw->y[i] = y[i];
        raw->z[i] = z[i];
    }
    return raw;
}

void swap(double *a, double *b) {
  double t = *a;
  *a = *b;
  *b = t;
}

// function to find the partition position
int partition(t_point_cloud *cloud, int low, int high) {
  
  // select the c element as pivot
  double pivot = cloud->x[high];
  
  // pointer for greater element
  int i = (low - 1);

  // traverse each element of the array
  // compare them with the pivot
  for (int j = low; j < high; j++) {
    if (cloud->x[j] <= pivot) {
        
      // if element smaller than pivot is found
      // swap it with the greater element pointed by i
      i++;
      
      // swap element at i with element at j
      swap(&cloud->x[i], &cloud->x[j]);
      swap(&cloud->y[i], &cloud->y[j]);
      swap(&cloud->z[i], &cloud->z[j]);
    }
  }

  // swap the pivot element with the greater element at i
  
  swap(&cloud->x[i+1], &cloud->x[high]);
  swap(&cloud->y[i+1], &cloud->y[high]);
  swap(&cloud->z[i+1], &cloud->z[high]);
  // return the partition point
  return (i + 1);
}

void quickSort(t_point_cloud *cloud, int low, int high) {
  if (low < high) {
    
    // find the pivot element such that
    // elements smaller than pivot are on left of pivot
    // elements greater than pivot are on right of pivot
    int pi = partition(cloud, low, high);
    
    // recursive call on the left of pivot
    quickSort(cloud, low, pi - 1);
    
    // recursive call on the right of pivot
    quickSort(cloud, pi + 1, high);
  }
}

t_point_cloud* drivable_data(t_point_cloud* cloud){
    double x[cloud->npoints];
    double y[cloud->npoints];
    double z[cloud->npoints];
    int section_npoints=0;
    double begin_section=2;
    double slope;
    int drivable_npoints=0;
    int total_iter=0;
    int exit=0;
    double reference_point[3];
    int once_per_cicle=1;
    double max_slope=0.3;
    quickSort(cloud,0,cloud->npoints-1);

    //Primeiro ponto de referencia
    //for procura da condição de y
    for(int i=0;i<cloud->npoints;i++){
        if(cloud->y[i]<1 && cloud->y[i]>-1){
            reference_point[0]=cloud->x[i];
            reference_point[1]=cloud->y[i];
            reference_point[2]=cloud->z[i];
            break;
        }
    }

    while(begin_section<cloud->x[cloud->npoints-1]){
        once_per_cicle=1;
        for(int i = total_iter-1; i < cloud->npoints; i++){
            if (cloud->x[i]>begin_section && cloud->x[i]<begin_section+0.2){
                section_npoints++;
                continue;
            }
            if(cloud->x[i]>begin_section+0.2){
                break;
            }
        }
        begin_section+=0.2;

        //for na secção à procura de ponto de referencia
        //condição de paragem o slope com o ponto de refencia anterior ser <20%
        for(int i=total_iter;i<total_iter +section_npoints;i++){
            if(cloud->y[i]<1 && cloud->y[i]>-1){
                slope=(cloud->z[i]-reference_point[2]);
                if(slope<max_slope && slope>0-max_slope){
                    reference_point[0]=cloud->x[i];
                    reference_point[1]=cloud->y[i];
                    reference_point[2]=cloud->z[i];
                    break;
                }
                //else(){ Se entrar no else é porque existe um obstáculo em frente ao carro e tem que remover todos os pontos à frente do obstáculo. Parar de analisar os pontos à frente
                //}
            }
        }


        for(int i=total_iter;i<total_iter+section_npoints;i++){
    
            slope=cloud->z[i]-reference_point[2];
         
            if(cloud->y[i]<1 && cloud->y[i]>-1){
                if(slope>max_slope || slope<0-max_slope){
                    printf("último x - %lf\n",cloud->x[i]);
                    printf("último y - %lf\n",cloud->y[i]);
                    printf("último z - %lf\n",cloud->z[i]);
                    printf("reference x - %lf\n",reference_point[0]);
                    printf("reference y - %lf\n",reference_point[1]);
                    printf("reference z - %lf\n",reference_point[2]);
                    printf("Last: slope: %lf\n",slope);
                    exit=1;
                    break;
                }

            }
            if(slope>max_slope || slope< 0-max_slope){
                continue;
            }
            
            x[drivable_npoints]=cloud->x[i];
            y[drivable_npoints]=cloud->y[i];
            z[drivable_npoints]=cloud->z[i];
            drivable_npoints++;
        }
        total_iter+=section_npoints;
        section_npoints=0;
        if(exit){
            break;
        }
        
    }
    
    cloud->x = (double *) realloc(cloud->x,drivable_npoints* sizeof(double));
    cloud->y = (double *) realloc(cloud->y,drivable_npoints* sizeof(double));
    cloud->z = (double *) realloc(cloud->z,drivable_npoints* sizeof(double));
    cloud->npoints = drivable_npoints;    
    
    for(int i = 0; i < cloud->npoints; i++){
        cloud->x[i] = x[i];
        cloud->y[i] = y[i];
        cloud->z[i] = z[i];
    }
    return cloud;
}