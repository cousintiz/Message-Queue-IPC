#define _GNU_SOURCE
#define TSCSECF     1e9
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <math.h>
#include <malloc.h>

typedef struct{
    double *x, *y, *z;
    int npoints;
}t_point_cloud;

/*mutex para threads*/
pthread_mutex_t mutex[2];

/*global var for cloud pointers stages of processing*/
t_point_cloud *cloud_raw, *cloud_drivable, *cloud_clean; 

t_point_cloud* read_data(char *filename);
t_point_cloud* clean_data(t_point_cloud* raw);
t_point_cloud* drivable_data(t_point_cloud* cloud);

double sectimeget(struct timespec *ts);

void* f1(void *args){
    //read data
    char *namefile[] = {"point_cloud1.txt", "point_cloud2.txt", "point_cloud3.txt"};
    
    for(int i=0; i< 3; i++){
        pthread_mutex_lock(&mutex[0]);
        cloud_raw = read_data(namefile[i]);
        pthread_mutex_unlock(&mutex[0]);
    }
    
    pthread_exit(NULL);
}

void* f2(void *args){
    // clean data
    pthread_mutex_lock(&mutex[0]);
    pthread_mutex_lock(&mutex[1]);
    cloud_clean = clean_data(cloud_raw);
    pthread_mutex_unlock(&mutex[0]);
    pthread_mutex_unlock(&mutex[1]);

    pthread_exit(NULL);
}

void* f3(void *arg){
    //drivable data
    pthread_mutex_lock(&mutex[0]);
    pthread_mutex_lock(&mutex[1]);
    cloud_drivable = drivable_data(cloud_clean);
    pthread_mutex_unlock(&mutex[0]);
    pthread_mutex_unlock(&mutex[1]);

    pthread_exit(NULL);
}

int main(int argc, char *argv[]){

    /*threads var*/
    pthread_t t_f1, t_f2, t_f3; 
    cloud_raw = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    cloud_drivable = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    /*mutex init*/
    pthread_mutex_init(&mutex[0], NULL); 
    pthread_mutex_init(&mutex[1], NULL); 

    /*create threads*/
    if(pthread_create(&t_f1,NULL,f1,NULL)){
        puts("error creating threads");
        exit(-1);
    }
    if(pthread_create(&t_f2,NULL,f2,NULL)){
        puts("error creating threads");
        exit(-1);
    }
    if(pthread_create(&t_f3,NULL,f3,NULL)){
        puts("error creating threads");
        exit(-1);
    }

    /*wait for threads to finish*/
    pthread_join(t_f1, NULL);
    pthread_join(t_f1, NULL);
    pthread_join(t_f1, NULL);

    /*destroy mutex*/
    pthread_mutex_destroy(&mutex[0]); 
    pthread_mutex_destroy(&mutex[1]); 
    
    return 0;
}

double sectimeget(struct timespec *ts)
{
    double tsc;
    tsc = ts->tv_nsec;
    tsc /= TSCSECF;
    tsc += ts->tv_sec;
    return tsc;
}

t_point_cloud* read_data(char *filename){
    unsigned int lines = 0;
    char buffer[100];
    double aux = 0.0;
    double sum[3] = {0.0,0.0,0.0}, prod[3] = {0.0,0.0,0.0}; 
    double mean[3] = {0.0,0.0,0.0}, dev[3] = {0.0,0.0,0.0}; 
    double min[3] = {0.0,0.0,0.0}, max[3] = {0.0,0.0,0.0}; /*0,1,2 = x, y, z*/

   
    FILE *file = fopen(filename,"r");/*abrir ficheiro para leitura*/
    if( file == NULL){
        printf("error opening file: %s", filename);
        exit(EXIT_FAILURE);
    }

    /*saber nr de linhas/size de dados a alocar*/
    while(fgets(buffer, sizeof(buffer), file)){
        lines++;
    }
    printf("num of points: %d \n", lines); 

    /*alocar espaço x,y,z*/
    
    cloud_raw->npoints = lines;
    cloud_raw->x = (double *) malloc(lines* sizeof(double));
    cloud_raw->y = (double *) malloc(lines* sizeof(double));
    cloud_raw->z = (double *) malloc(lines* sizeof(double));
     
    fseek(file, 0, SEEK_SET); /*por pointer no começo*/
    
    for(int i = 0; i < cloud_raw->npoints; i++){
        fscanf(file, "%lf %lf %lf\n", &cloud_raw->x[i], &cloud_raw->y[i], &cloud_raw->z[i]);/*ler dados*/
        sum[0] += cloud_raw->x[i]; 
        sum[1] += cloud_raw->y[i];
        sum[2] += cloud_raw->z[i];
        prod[0] += cloud_raw->x[i] * cloud_raw->x[i];
        prod[1] += cloud_raw->y[i] * cloud_raw->y[i];
        prod[2] += cloud_raw->z[i] * cloud_raw->z[i];

    }
   
    for(int i = 0; i < 3; i++){
        mean[i] = sum[i] / cloud_raw->npoints;/*mean = sum / n*/
        aux = (prod[i]/cloud_raw->npoints - (mean[i]*mean[i]));  /* std = sqrt(prod/n - mean^2)*/
        dev[i] = sqrt( aux);
    }
    
    for(int i = 0; i < cloud_raw->npoints; i++){
        /*minimos*/
        if(min[0] > cloud_raw->x[i]){
            min[0] = cloud_raw->x[i];
        }
        if(min[1] > cloud_raw->y[i]){
            min[1] = cloud_raw->y[i];
        }
        if(min[2] > cloud_raw->z[i]){
            min[2] = cloud_raw->z[i];
        }

        /*maximos*/
        if(max[0] < cloud_raw->x[i]){
            max[0] = cloud_raw->x[i];
        }
        if(max[1] < cloud_raw->y[i]){
            max[1] = cloud_raw->y[i];
        }
        if(max[2] <cloud_raw->z[i]){
            max[2] = cloud_raw->z[i];
        }

    }
    
    printf("\nXmax = %lf, Ymax = %lf, Zmax = %lf\n\n", max[0], max[1], max[2]);
    printf("Xmin = %lf, Ymin = %lf, Zmin = %lf\n\n", min[0], min[1], min[2]);
    printf("Xmean = %lf, Ymean = %lf, Zmean = %lf\n\n", mean[0], mean[1], mean[2]);
    printf("Xstdev = %lf, Ystdev = %lf, Zstdev = %lf\n\n", dev[0], dev[1], dev[2]);
   
    return cloud_raw;
}

t_point_cloud* clean_data(t_point_cloud* raw){

    int clean_npoints=raw->npoints;
    int j=0;
    double x[raw->npoints];
    double y[raw->npoints];
    double z[raw->npoints];

    for(int i = 0; i < raw->npoints; i++){
        if (raw->x[i]<2||raw->x[i]>30){
            clean_npoints--;
            continue;
        }
        if ( raw->y[i]>10 || raw->y[i]<-10){
            clean_npoints--;
            continue;
        }
        x[j] = raw->x[i];
        y[j] = raw->y[i];
        z[j] = raw->z[i];
        j++;
    }

    cloud_clean = (t_point_cloud*)malloc(sizeof(t_point_cloud));
    cloud_clean->x = (double *) malloc(clean_npoints* sizeof(double));
    cloud_clean->y  = (double *) malloc(clean_npoints* sizeof(double));
    cloud_clean->z = (double *) malloc(clean_npoints* sizeof(double));
    malloc_trim(0);

    cloud_clean->npoints=clean_npoints;
    //printf("PROBLEM END\n");
    for(int i = 0; i < cloud_clean->npoints; i++){
        cloud_clean->x[i] = x[i];
        cloud_clean->y[i] = y[i];
        cloud_clean->z[i] = z[i];
    }
    return cloud_clean;
}

void swap(double *a, double *b) {
  double t = *a;
  *a = *b;
  *b = t;
}

// function to find the partition position
int partition(t_point_cloud *cloud, int low, int high) {
  
  // select the c element as pivot
  double pivot = cloud->x[high];
  
  // pointer for greater element
  int i = (low - 1);

  // traverse each element of the array
  // compare them with the pivot
  for (int j = low; j < high; j++) {
    if (cloud->x[j] <= pivot) {
        
      // if element smaller than pivot is found
      // swap it with the greater element pointed by i
      i++;
      
      // swap element at i with element at j
      swap(&cloud->x[i], &cloud->x[j]);
      swap(&cloud->y[i], &cloud->y[j]);
      swap(&cloud->z[i], &cloud->z[j]);
    }
  }

  // swap the pivot element with the greater element at i
  
  swap(&cloud->x[i+1], &cloud->x[high]);
  swap(&cloud->y[i+1], &cloud->y[high]);
  swap(&cloud->z[i+1], &cloud->z[high]);
  // return the partition point
  return (i + 1);
}

void quickSort(t_point_cloud *cloud, int low, int high) {
  if (low < high) {
    
    // find the pivot element such that
    // elements smaller than pivot are on left of pivot
    // elements greater than pivot are on right of pivot
    int pi = partition(cloud, low, high);
    
    // recursive call on the left of pivot
    quickSort(cloud, low, pi - 1);
    
    // recursive call on the right of pivot
    quickSort(cloud, pi + 1, high);
  }
}

t_point_cloud* drivable_data(t_point_cloud* cloud){
    double x[cloud->npoints];
    double y[cloud->npoints];
    double z[cloud->npoints];
    int section_npoints=0;
    double begin_section=2;
    double slope;
    int drivable_npoints=0;
    int total_iter=0;
    int exit=0;
    double reference_point[3];
    int once_per_cicle=1;
    double max_slope=0.3;
    quickSort(cloud,0,cloud->npoints-1);

    //Primeiro ponto de referencia
    //for procura da condição de y
    for(int i=0;i<cloud->npoints;i++){
        if(cloud->y[i]<1 && cloud->y[i]>-1){
            reference_point[0]=cloud->x[i];
            reference_point[1]=cloud->y[i];
            reference_point[2]=cloud->z[i];
            break;
        }
    }

    while(begin_section<cloud->x[cloud->npoints-1]){
        once_per_cicle=1;
        for(int i = total_iter-1; i < cloud->npoints; i++){
            if (cloud->x[i]>begin_section && cloud->x[i]<begin_section+0.2){
                section_npoints++;
                continue;
            }
            if(cloud->x[i]>begin_section+0.2){
                break;
            }
        }
        begin_section+=0.2;

        //for na secção à procura de ponto de referencia
        //condição de paragem o slope com o ponto de refencia anterior ser <20%
        for(int i=total_iter;i<total_iter +section_npoints;i++){
            if(cloud->y[i]<1 && cloud->y[i]>-1){
                slope=(cloud->z[i]-reference_point[2]);
                if(slope<max_slope && slope>0-max_slope){
                    reference_point[0]=cloud->x[i];
                    reference_point[1]=cloud->y[i];
                    reference_point[2]=cloud->z[i];
                    break;
                }
                //else(){ Se entrar no else é porque existe um obstáculo em frente ao carro e tem que remover todos os pontos à frente do obstáculo. Parar de analisar os pontos à frente
                //}
            }
        }


        for(int i=total_iter;i<total_iter+section_npoints;i++){
    
            slope=cloud->z[i]-reference_point[2];
         
            if(cloud->y[i]<1 && cloud->y[i]>-1){
                if(slope>max_slope || slope<0-max_slope){
                    printf("último x - %lf\n",cloud->x[i]);
                    printf("último y - %lf\n",cloud->y[i]);
                    printf("último z - %lf\n",cloud->z[i]);
                    printf("reference x - %lf\n",reference_point[0]);
                    printf("reference y - %lf\n",reference_point[1]);
                    printf("reference z - %lf\n",reference_point[2]);
                    printf("Last: slope: %lf\n",slope);
                    exit=1;
                    break;
                }

            }
            if(slope>max_slope || slope< 0-max_slope){
                continue;
            }
            
            x[drivable_npoints]=cloud->x[i];
            y[drivable_npoints]=cloud->y[i];
            z[drivable_npoints]=cloud->z[i];
            drivable_npoints++;
        }
        total_iter+=section_npoints;
        section_npoints=0;
        if(exit){
            break;
        }
        
    }
    
    cloud_drivable->x = (double *) malloc(drivable_npoints* sizeof(double));
    cloud_drivable->y = (double *) malloc(drivable_npoints* sizeof(double));
    cloud_drivable->z = (double *) malloc(drivable_npoints* sizeof(double));
    cloud_drivable->npoints = drivable_npoints;    
    
    for(int i = 0; i < cloud->npoints; i++){
        cloud->x[i] = x[i];
        cloud->y[i] = y[i];
        cloud->z[i] = z[i];
    }
    return cloud;
}