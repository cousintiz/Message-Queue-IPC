#define _GNU_SOURCE
#include <stdio.h>
#include <err.h>
#include "func.h"
#include <pthread.h>
#include <unistd.h>
#include <sched.h>
#include <sys/resource.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sched.h>


truct th_args
{
  int num;
 
};


int main(int argc, char** argv){
    int prio = 0;
    int _pid = getpid();

    int _tasks = 3; /*threads*/

    struct timespec start1, end1, start2, end2, start3, end3;/*struct para obter tempo*/
    double ns = 1000000000.0; /*divisor para ter ns em segundos*/
    double spent1, spent2, spent3;
    spent1 = spent2 = spent3 = 0.0; /*iniciaizar as variables que vao guardar o tempo*/

    cpu_set_t  mask;
    CPU_ZERO(&mask);
    CPU_SET(0, &mask); /*cpu_id e a mask*/


    // tratar da memoria para evitar swap ins and outs
    if(mlockall(MCL_CURRENT|MCL_FUTURE)==-1){
        err(EXIT_FAILURE, "mockall error");
    }

    if( CPU_ISSET(0, &mask) == -1){
        err(EXIT_FAILURE, "CPU not in the set");
    }

    if( sched_setaffinity(_pid, sizeof(mask), &mask) == -1){
        err(EXIT_FAILURE, "sched_setaffinity");
    }
    //obter a prioridade maxima
    if( (prio = sched_get_priority_max(SCHED_FIFO)) == -1){
        err(EXIT_FAILURE, "In getting sched priority");
    }
    //atribuir a prioridade maxima ao proceso

    if( setpriority(PRIO_PROCESS, _pid, prio) ==-1){
        err(EXIT_FAILURE, "setting priority...");
    }
1
    struct th_args args;
    pthread_t task[_tasks];

    for (int i = 0; i < _tasks; i++)
    {
        args.num = i + 1; /*reader number to the thread arg struct*/
        if (pthread_create(&task[i], NULL, func, &args) != 0)
        {
        perror("failled to creat thread for reader\n");
        }
    }

    for (int i = 0; i < _tasks; i++)
    {
        if (pthread_join(task[i], NULL))
        {
        perror("failled to join thread for reader\n");
    }










    if(munlockall()==-1){
        err(EXIT_FAILURE, "munlockall error");
    }

    exit(EXIT_SUCCESS);
}