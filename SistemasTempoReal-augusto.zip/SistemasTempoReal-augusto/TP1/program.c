#define _GNU_SOURCE
#include <stdio.h>
#include <err.h>
#include "func.h"
#include <unistd.h>
 #include <sched.h>
#include <sys/resource.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sched.h>

int main(int argc, char** argv){
    int prio = 0;
    int _pid = getpid();

    struct timespec start1, end1, start2, end2, start3, end3;/*struct para obter tempo*/
    double ns = 1000000000.0; /*divisor para ter ns em segundos*/
    double spent1, spent2, spent3;
    spent1 = spent2 = spent3 = 0.0; /*iniciaizar as variables que vao guardar o tempo*/

    cpu_set_t  mask;
    CPU_ZERO(&mask);
    CPU_SET(0, &mask); /*cpu_id e a mask*/


    // tratar da memoria para evitar swap ins and outs
    if(mlockall(MCL_CURRENT|MCL_FUTURE)==-1){
        err(EXIT_FAILURE, "mockall error");
    }

    if( CPU_ISSET(0, &mask) == -1){
        err(EXIT_FAILURE, "CPU not in the set");
    }

    if( sched_setaffinity(_pid, sizeof(mask), &mask) == -1){
        err(EXIT_FAILURE, "sched_setaffinity");
    }
    //obter a prioridade maxima
    if( (prio = sched_get_priority_max(SCHED_FIFO)) == -1){
        err(EXIT_FAILURE, "In getting sched priority");
    }
    //atribuir a prioridade maxima ao proceso

    if( setpriority(PRIO_PROCESS, _pid, prio) ==-1){
        err(EXIT_FAILURE, "setting priority...");
    }
    //medicoes de tempo
    clock_gettime(CLOCK_MONOTONIC, &start1);
    f1(1,1);
    clock_gettime(CLOCK_MONOTONIC, &end1);
    spent1 = (end1.tv_sec-start1.tv_sec)+(end1.tv_nsec-start1.tv_nsec)/ns;/*obter o tempo*/
    printf("F1 time of execution: %1lf\n", spent1);

    clock_gettime(CLOCK_MONOTONIC, &start2);
    f2(1,1);
    clock_gettime(CLOCK_MONOTONIC, &end2);
    spent2 = (end2.tv_sec-start2.tv_sec)+(end2.tv_nsec-start2.tv_nsec)/ns;/*obter o tempo*/
    printf("F2 time of execution: %1lf\n", spent2);

    clock_gettime(CLOCK_MONOTONIC, &start3);
    f3(1,1);
    clock_gettime(CLOCK_MONOTONIC, &end3);
    spent3 = (end3.tv_sec-start3.tv_sec)+(end3.tv_nsec-start3.tv_nsec)/ns;/*obter o tempo*/
    printf("F1 time of execution: %1lf\n", spent3);

    if(munlockall()==-1){
        err(EXIT_FAILURE, "munlockall error");
    }

    exit(EXIT_SUCCESS);
}