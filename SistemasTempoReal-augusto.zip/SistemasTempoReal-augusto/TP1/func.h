#include <time.h>

void f1(int, int);

void f2(int, int);

void f3(int, int);
